# TurretKiller

Use shovel or knife to kill the turrets
![](https://github.com/P-Asta/TurretKiller/raw/refs/heads/main/assets/test.gif)
